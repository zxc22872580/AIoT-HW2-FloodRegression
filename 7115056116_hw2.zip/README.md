# HW2 — 多元線性回歸 × CRISP-DM
### Kaggle Playground Series S4E5：Flood Prediction

以 **CRISP-DM** 六階段流程，對 Kaggle 洪水機率預測資料集（20 個特徵）執行完整的多元線性回歸分析，
包含**特徵選擇**、**模型評估**、**OLS 五大假設檢定**，以及**含信賴區間與預測區間的預測圖**。

---

## 📌 核心發現

以**真實 Kaggle 競賽資料**（5,000 列公開鏡像抽樣）執行，所有數值來自 `outputs/results.json`。

| 發現 | 內容 |
|---|---|
| **生成規則被直接證明** | 載入原始 50,000 列資料集驗證 `目標 = 0.005 × 總和` 精確成立，最大偏差 1.11×10⁻¹⁶ |
| **可加性結構** | 單一特徵與目標相關係數僅 0.2136，20 特徵**逐列總和**達 0.9131 |
| **最終模型表現** | 多元線性回歸測試集 R² = **0.8405**，冠軍為 0.86905（資料量僅其 1/224） |
| **特徵選擇結論：全部保留** | k-sweep 嚴格遞增至 k=20；僅留 10 特徵時 R² 掉到 0.3455 |
| **兩項 OLS 假設被違反** | 異質變異 p≈10⁻¹⁸、殘差偏態 +0.76，已加計 HC3 穩健標準誤，僅 1 項邊界特徵受影響 |
| **預測區間實測校準** | 95% PI 實際覆蓋 **92.90%**，低估 2.1 個百分點，報告中如實揭露 |
| **Kaggle 名次定位** | 真實 private leaderboard 2,794 隊，本模型約第 2,341 名（榜單極度壓縮，見報告 §7.1） |

## 🚀 快速開始

### 1. 安裝套件

```bash
pip install numpy pandas scikit-learn matplotlib seaborn scipy statsmodels joblib
```

### 2. 下載資料

至 <https://www.kaggle.com/competitions/playground-series-s4e5/data> 下載並放入 `data/`：

```
data/train.csv     （必要）
data/test.csv      （選用，用於產生 Kaggle 提交檔）
```

> 若 `data/train.csv` 不存在，程式會自動改用**合成替代資料**執行，
> 以便在無 Kaggle 帳號時仍能驗證整條流程。
> 該模式下所有數值僅供參考，**不可用於繳交**。

### 3. 執行

```bash
python 7115056116_hw2.py
```

快速冒煙測試（抽樣 12 萬列）：

```bash
python 7115056116_hw2.py --fast
```

---

## 📁 產出檔案

```
outputs/
├── results.json                      所有數值結果（報告數字的唯一來源）
├── run_log.txt                       完整執行紀錄
├── 7115056116_final_model.joblib     封存的模型（含 scaler）
├── submission.csv                    Kaggle 提交檔（需 test.csv）
├── figures/
│   ├── 01_target_distribution.png        目標分布與 Q-Q 圖
│   ├── 02_feature_distributions.png      20 個特徵分布
│   ├── 03_correlation_heatmap.png        相關係數矩陣
│   ├── 04_key_insight_rowsum.png         ⭐ 關鍵洞察：逐列總和 vs 目標
│   ├── 05_feature_selection.png          特徵選擇與 k-sweep 曲線
│   ├── 06_model_comparison.png           8 個模型比較
│   ├── 07_residual_diagnostics.png       殘差診斷（OLS 假設）
│   ├── 08_coefficients_ci.png            係數與 95% 信賴區間
│   └── 09_prediction_with_intervals.png  ⭐ 預測圖（含 CI 與 PI）
└── tables/
    ├── 02_feature_profile.csv
    ├── 03_feature_selection_ranking.csv
    ├── 04_feature_selection_k_sweep.csv
    ├── 05_model_comparison.csv
    ├── 06_ols_coefficients.csv
    ├── 07_vif.csv
    └── 08_prediction_interval_sample.csv
```

---

## 🔄 CRISP-DM 流程對照

| 階段 | 程式位置 | 主要內容 |
|---|---|---|
| **1. Business Understanding** | `business_understanding()` | 防災預算分配場景；論證為何需要「線性」模型（可稽核／可行動／低成本） |
| **2. Data Understanding** | `data_understanding()` | 資料品質、分布、相關性；發現可加性結構 |
| **3. Data Preparation** | `data_preparation()` | 缺失值、離群值決策、非線性聚合特徵、切分、標準化 |
| **3.6 Feature Selection** | `feature_selection()` | 5 種方法交叉驗證 + k-sweep |
| **4. Modeling** | `modeling()` | 8 個模型（含單純／多元 LR、Ridge、Lasso、ElasticNet、樹模型對照） |
| **5. Evaluation** | `evaluation()` | MAE/MSE/RMSE/R²/Adj-R²、5-fold CV、OLS 五大假設、CI 與 PI |
| **6. Deployment** | `deployment()` | 全量重訓、模型封存、評分 API、提交檔、監控計畫 |

---

## 🧠 兩個關鍵技術判斷

### 1. 為何不加入 `agg_sum`？

`agg_sum`（逐列總和）是 20 個原始特徵的**精確線性組合**，`agg_mean` 則是其 1/20。
對**線性模型**而言兩者增加的資訊量**恰好為零**，卻會使設計矩陣奇異，
導致所有標準誤、p 值與 VIF 失去意義。程式中的 `prove_sum_is_redundant()` 以實證驗證：

```
20 raw features            -> test R² = 0.8553774381
20 raw features + agg_sum  -> test R² = 0.8553774381
difference                 = +1.11e-16
```

這正是與網路上**樹模型**筆記本的關鍵差異：樹無法自行構造加權總和，所以 `sum` 對它們幫助極大；
線性模型早已免費擁有總和，真正缺的是**非線性項**。因此只加入 7 個非線性聚合特徵。

### 2. 信賴區間 vs 預測區間

| | 涵蓋對象 | 平均寬度 | 經驗覆蓋率 |
|---|---|---|---|
| 95% **信賴**區間 CI | 平均反應的估計誤差 | 0.00664 | 9.60% |
| 95% **預測**區間 PI | 單一新觀測值 | 0.07881 | **92.90%** |

PI 約為 CI 的 **11.9 倍寬**，因此預測圖附有**放大插圖**才能辨識 CI。
CI 覆蓋率低是**正確行為**——它本來就不是用來涵蓋個別觀測值的。

PI 實測 92.90% 低於名目 95%，成因是殘差非常態（偏態 +0.76）。
報告選擇**實測並揭露**而非只畫出好看的色帶。

## ✅ 繳交前檢查清單

- [ ] 將 `7115056116` 全部替換為實際學號（檔名、`STUDENT_ID` 變數、報告標題）
- [ ] 放入真實 `data/train.csv` 與 `data/test.csv` 並重新執行
- [ ] 依 `outputs/results.json` 更新 `REPORT.md` **第 7.1 節關鍵數值總表**
- [ ] 上傳 `outputs/submission.csv` 至 Kaggle，將名次／分數填入第 7.1 節
- [ ] 匯出 ChatGPT 對話為 `GPT_conversation.pdf`（pdfCrowd 或列印為 PDF）
- [ ] 以 NotebookLM 產生研究摘要，取代 `REPORT.md` 第 11 節草稿，並附使用截圖
- [ ] 將 `REPORT.md` 轉為 PDF
- [ ] 壓縮為 `7115056116_hw2.zip`

---

## 📚 參考資料

- 競賽頁面 — <https://www.kaggle.com/competitions/playground-series-s4e5>
- 1st Place Solution — <https://www.kaggle.com/competitions/playground-series-s4e5/writeups/aldparis-1st-place-solution>
- 2nd Place Solution — <https://www.kaggle.com/competitions/playground-series-s4e5/writeups/peaky-blenders-2nd-place-solution-team-peaky-blend>
- 討論串（sum baseline） — <https://www.kaggle.com/competitions/playground-series-s4e5/discussion/499263>
